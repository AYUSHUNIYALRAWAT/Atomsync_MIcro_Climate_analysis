# AtmoSync processed and curated data

## Contents
- `processed/`: cleaned, typed source tables; original raw files are not modified.
- `curated/`: analysis-ready joined and aggregated datasets.

## Processing decisions
1. Sensor events are de-duplicated on `event_id`, keeping the first occurrence.
2. Sensor timestamps are parsed as UTC and standardized to ISO-8601 UTC strings.
3. Physically invalid sensor values are set to missing: temperature outside -10 to 60 °C, humidity outside 0 to 100%, vibration outside 0 to 5 g. These are data-quality bounds, NOT commodity safety limits.
4. Missing/invalid sensor values are retained as flags and imputed in separate `*_clean` columns by linear interpolation within each container, then container median fallback. Original measurement values are preserved in `*_raw` columns; validated measurement columns are set to null when invalid.
5. Weather is joined to sensor events by nearest available weather station (Haversine distance from event GPS) and matching UTC hour.
6. Market prices are converted from INR/quintal to INR/kg by dividing by 100. Original price columns are retained.
7. Daily summaries aggregate cleaned sensor readings per container and UTC date.

## Critical limitations
The source pack declares all starter records synthetic/placeholders. The curated files therefore remain synthetic and are suitable for pipeline development, EDA and dashboard prototyping only. Weather records are not verified Open-Meteo observations; market prices are not verified AGMARKNET observations; routes are illustrative estimates. No verified spoilage/quality labels or validated commodity storage rules are included. Do not treat these outputs as real shipment telemetry, validated spoilage predictions, or operational rerouting advice.

## Files
### processed
- `sensor_events_processed.csv`
- `containers_processed.csv`
- `weather_processed.csv`
- `commodity_market_prices_processed.csv`
- `market_routes_processed.csv`
- `data_quality_report.csv`

### curated
- `sensor_shipment_weather_curated.csv` (event-level sensor + container + nearest hourly weather)
- `container_daily_summary_curated.csv` (daily container-level aggregates)
- `container_latest_snapshot_curated.csv` (latest event per container)
- `market_prices_curated.csv`
- `routes_curated.csv`
